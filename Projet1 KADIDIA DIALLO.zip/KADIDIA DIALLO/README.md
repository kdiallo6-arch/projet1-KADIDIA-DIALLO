# Projet 1 - Analyse des journaux d'un pare-feu
**Nom / Prénom** : [Votre NOM et Prénom]  
**Classe** : L3  

## Lancement du projet
1. Installer les dépendances :
   ```bash
   pip install -r requirements.txtv