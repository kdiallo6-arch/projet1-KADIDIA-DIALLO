# Rapport d'Analyse Sécurité - Journaux du Pare-Feu

## 1. Résumé des Observations
L'analyse des 5 440 connexions enregistrées par le pare-feu met en évidence un trafic majoritairement légitime orienté vers le web sécurisé (port 443 HTTPS). Le taux global de blocage (DENY) s'élève à 13.57 %, reflétant un niveau d'activité de filtrage usuel. Cependant, l'examen approfondi des métriques révèle deux anomalies majeures qui menacent la sécurité du réseau interne.

## 2. Comportements Suspects Identifiés

### Suspect 1 : Balayage de ports (Port Scanning) par l'IP `192.168.1.99`
* **Preuve chiffrée** : L'adresse IP source `192.168.1.99` (de type `PC`) a contacté **328 ports distincts** à travers 400 tentatives de connexion, dont **383 se sont soldées par un rejet (DENY)**.
* **Interprétation** : Ce comportement est caractéristique d'une phase de reconnaissance automatique (scan réseau) visant à identifier des services vulnérables exposés sur le réseau.

### Suspect 2 : Exfiltration massive de données par l'IP `192.168.1.11`
* **Preuve chiffrée** : L'IP `192.168.1.11` (`camera_IoT`) a émis au total **247.89 Mo** de données, dont plus de **259.4 Mo vers une IP externe publique (`8.8.8.8`) sur le port `8080`**.
* **Interprétation** : Une caméra IoT ne doit pas transférer un tel volume vers l'extérieur. Cela indique une forte suspicion de piratage et d'exfiltration de données.

## 3. Recommandations de Sécurité
1. **Segmentation réseau (VLAN / IoT)** : Isoler tous les objets connectés (`camera_IoT`, `capteur_IoT`) dans un VLAN dédié sans accès direct à Internet.
2. **Isolation de la machine `192.168.1.99`** : Déconnecter ce PC du réseau pour réaliser un scan antivirus complet et une analyse forensic.
3. **Restreindre les flux sortants** : Configurer le pare-feu pour interdire aux équipements IoT de communiquer avec des adresses externes non autorisées et fermer les services non sécurisés (ex. Telnet/port 23).