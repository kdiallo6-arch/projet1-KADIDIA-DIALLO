import os
import json
import pandas as pd
import matplotlib.pyplot as plt

def charger_et_nettoyer():
    # Détermine le chemin absolu du dossier du script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    fichier_csv = os.path.join(base_dir, 'data', 'logs_reseau.csv')
    
    # Vérification explicite du fichier
    if not os.path.exists(fichier_csv):
        raise FileNotFoundError(f"Le fichier est introuvable à l'adresse : {fichier_csv}. Vérifiez qu'il est bien placé dans le dossier 'data'.")

    # 1. Chargement des données
    df = pd.read_csv(fichier_csv)
    
    # 2. Supprimer les doublons exacts
    df = df.drop_duplicates().copy()
    
    # 3. Mettre protocol en MAJUSCULES
    if 'protocol' in df.columns:
        df['protocol'] = df['protocol'].astype(str).str.upper()
        
    # 4. Remplacer les bytes_sent manquants par la médiane
    mediane_bytes = df['bytes_sent'].median()
    df['bytes_sent'] = df['bytes_sent'].fillna(mediane_bytes)
    
    return df

def calculer_resultats(df):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    nb_lignes = len(df)
    top_port = int(df['dst_port'].mode()[0])
    taux_deny_pct = round(float((df['action'] == 'DENY').mean() * 100), 2)
    ip_scanner = str(df.groupby('src_ip')['dst_port'].nunique().idxmax())
    ip_exfiltration = str(df.groupby('src_ip')['bytes_sent'].sum().idxmax())
    
    res = {
        "nb_lignes_apres_nettoyage": nb_lignes,
        "top_port": top_port,
        "taux_deny_pct": taux_deny_pct,
        "ip_scanner": ip_scanner,
        "ip_exfiltration": ip_exfiltration
    }
    
    fichier_json = os.path.join(base_dir, 'resultats.json')
    with open(fichier_json, 'w', encoding='utf-8') as f:
        json.dump(res, f, indent=2)
        
    print("-> Fichier resultats.json généré avec succès !")

def generer_figures(df):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dossier_figures = os.path.join(base_dir, 'figures')
    os.makedirs(dossier_figures, exist_ok=True)
    plt.style.use('ggplot')

    # Figure 1 : Top 10 des ports
    plt.figure(figsize=(8, 5))
    top_ports = df['dst_port'].value_counts().head(10)
    top_ports.plot(kind='bar', color='skyblue', edgecolor='black')
    plt.title('Top 10 des ports de destination les plus fréquentés')
    plt.xlabel('Port Destination')
    plt.ylabel('Nombre de connexions')
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(os.path.join(dossier_figures, 'top_ports.png'))
    plt.close()

    # Figure 2 : Répartition ALLOW vs DENY
    plt.figure(figsize=(6, 6))
    action_counts = df['action'].value_counts()
    plt.pie(action_counts, labels=action_counts.index, autopct='%1.1f%%', colors=['#2ecc71', '#e74c3c'], startangle=90)
    plt.title('Répartition des actions du pare-feu (ALLOW / DENY)')
    plt.tight_layout()
    plt.savefig(os.path.join(dossier_figures, 'repartition_actions.png'))
    plt.close()

    # Figure 3 : Volume d'octets par type d'appareil
    plt.figure(figsize=(8, 5))
    bytes_per_device = df.groupby('device_type')['bytes_sent'].sum() / (1024 * 1024)
    bytes_per_device.plot(kind='bar', color='orange', edgecolor='black')
    plt.title('Volume d octets envoyés par type d appareil (en Mo)')
    plt.xlabel('Type d appareil')
    plt.ylabel('Volume total (Mo)')
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.savefig(os.path.join(dossier_figures, 'volume_par_appareil.png'))
    plt.close()

    print("-> Figures générées dans le dossier figures/")

if __name__ == '__main__':
    df_clean = charger_et_nettoyer()
    calculer_resultats(df_clean)
    generer_figures(df_clean)